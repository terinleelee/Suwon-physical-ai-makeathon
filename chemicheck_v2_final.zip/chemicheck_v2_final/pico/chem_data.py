# =============================================================
#  케미체크 v2  chem_data.py — 용매·물질·혼합 규칙 표
#  이 파일의 표만 고치면 판정 규칙이 바뀝니다. (main.py와 함께 Pico에 저장)
#  OLED에 나오는 한글을 바꾸면 hangul16.py에 그 글자가 있어야 합니다.
# =============================================================

# 용매 = 파란 토큰.  태그 4번 블록에 'SV|<코드>' 로 기록
SOLVENTS = {
    # 코드: (OLED 이름, 화면용 화학식, 취급 위험 %, 설명)
    'H2O':  ('물',       'H2O',  0,  '무해한 극성 용매'),
    'ETOH': ('에탄올',   'EtOH', 10, '인화성 액체'),
    'ACET': ('아세톤',   'Acet', 10, '인화성이 큰 휘발성 용매'),
    'ACOH': ('아세트산', 'AcOH', 15, '산이면서 인화성인 용매(빙초산)'),
}
SOLVENT_KEYS = ('H2O', 'ETOH', 'ACET', 'ACOH')      # 등록 모드에서 키 1~4

# 섞을 물질 = 4x4 키패드 1~9
SUBSTANCES = {
    # 키: (코드, OLED 이름, 화학식, 취급 위험 %, 설명)
    '1': ('HCL',    '염산',             'HCl',    15, '부식성 산'),
    '2': ('NAOH',   '수산화나트륨',     'NaOH',   20, '강한 부식성 염기(고체)'),
    '3': ('H2O2',   '과산화수소',       'H2O2',   15, '산화제'),
    '4': ('NAOCL',  '표백제',           'NaOCl',  15, '산화성·부식성(차아염소산나트륨)'),
    '5': ('NH3',    '암모니아수',       'NH3',    15, '자극성 기체가 나오는 염기'),
    '6': ('H2SO4',  '진한 황산',        'H2SO4',  25, '강한 부식성·탈수성 산'),
    '7': ('KMNO4',  '과망가니즈산칼륨', 'KMnO4',  15, '강한 산화제'),
    '8': ('NAHCO3', '탄산수소나트륨',   'NaHCO3', 3,  '거의 무해한 약염기'),
    '9': ('NACL',   '염화나트륨',       'NaCl',   0,  '무해'),
}
MAX_PICK = 3

# 두 물질(용매 포함)이 만났을 때의 반응.  순서는 상관없음
RULES = (
    # (A, B, 위험 %, OLED 한글, OLED 영어, 이유)
    ('HCL',   'NAOCL',  90, '염소 기체 발생',   'CL2 GAS',     '산이 표백제와 만나면 독성 염소 기체가 나와요.'),
    ('H2SO4', 'NAOCL',  90, '염소 기체 발생',   'CL2 GAS',     '진한 황산도 산이라 표백제와 섞이면 염소 기체가 나와요.'),
    ('ACOH',  'NAOCL',  80, '염소 기체 발생',   'CL2 GAS',     '약한 산인 아세트산도 표백제와 섞이면 염소 기체가 나와요.'),
    ('KMNO4', 'HCL',    85, '염소 기체 발생',   'CL2 GAS',     '과망가니즈산칼륨이 염산을 산화시켜 염소 기체를 만들어요.'),
    ('NH3',   'NAOCL',  90, '클로라민 기체',    'CHLORAMINE',  '암모니아와 표백제가 만나면 독성 클로라민 기체가 생겨요.'),
    ('ETOH',  'NAOCL',  70, '클로로폼 생성',    'CHCl3 RISK',  '표백제가 에탄올과 반응하면 클로로폼이 생길 수 있어요.'),
    ('ACET',  'NAOCL',  75, '클로로폼 생성',    'CHCl3 RISK',  '표백제와 아세톤은 할로폼 반응으로 클로로폼을 만들어요.'),
    ('KMNO4', 'H2SO4',  95, '폭발 위험',        'EXPLOSION',   '진한 황산과 과망가니즈산칼륨은 폭발성 물질이 생길 수 있어 절대 섞지 않아요.'),
    ('H2SO4', 'H2O2',   90, '폭발 위험',        'PIRANHA',     '진한 황산과 과산화수소를 섞으면 피라냐 용액이 되어 큰 열을 내고, 유기물과 닿으면 폭발할 수 있어요.'),
    ('ACET',  'H2O2',   90, '폭발성 과산화물',  'PEROXIDE',    '아세톤과 과산화수소는 폭발성 과산화물이 생길 수 있어 절대 섞지 않아요.'),
    ('KMNO4', 'ETOH',   80, '화재 위험',        'FIRE RISK',   '강한 산화제가 인화성 용매에 닿으면 불이 붙을 수 있어요.'),
    ('KMNO4', 'ACET',   80, '화재 위험',        'FIRE RISK',   '강한 산화제가 인화성 용매에 닿으면 불이 붙을 수 있어요.'),
    ('KMNO4', 'ACOH',   55, '화재 위험',        'FIRE RISK',   '아세트산은 산이면서 인화성이라 산화제와 섞으면 위험해요.'),
    ('H2O2',  'ETOH',   55, '화재 위험',        'FIRE RISK',   '진한 과산화수소는 인화성 물질을 격렬하게 산화시킬 수 있어요.'),
    ('H2O2',  'ACOH',   55, '과아세트산 생성',  'PERACETIC',   '과산화수소와 아세트산이 만나 부식성이 강한 과아세트산이 생겨요.'),
    ('H2O',   'H2SO4',  55, '심한 발열',        'HOT SPLASH',  '진한 황산은 물에 녹을 때 큰 열이 나요. 반드시 물에 산을 조금씩 넣어요.'),
    ('H2SO4', 'ETOH',   50, '강한 발열',        'HEAT',        '진한 황산은 에탄올과 섞일 때 강한 열을 내요.'),
    ('H2SO4', 'ACET',   55, '강한 발열',        'HEAT',        '진한 황산과 아세톤은 열을 내며 격렬하게 반응할 수 있어요.'),
    ('H2SO4', 'NAOH',   60, '강한 중화 발열',   'HEAT',        '진한 산과 강한 염기의 중화는 끓어 튈 만큼 열이 나요.'),
    ('HCL',   'NAOH',   45, '중화 발열',        'NEUTRAL HEAT', '산과 염기가 만나 중화되면서 열이 나요.'),
    ('ACOH',  'NAOH',   35, '중화 발열',        'NEUTRAL HEAT', '아세트산과 수산화나트륨이 중화되면서 열이 나요.'),
    ('H2SO4', 'NH3',    50, '중화 발열',        'NEUTRAL HEAT', '진한 황산과 암모니아가 중화되면서 열이 많이 나요.'),
    ('HCL',   'NH3',    35, '흰 연기 발생',     'NH4Cl SMOKE', '염화수소와 암모니아가 만나 염화암모늄 흰 연기가 생겨요.'),
    ('ACOH',  'NH3',    25, '중화 발열',        'NEUTRAL HEAT', '아세트산과 암모니아가 중화되면서 열이 나요.'),
    ('H2O',   'NAOH',   25, '용해 발열',        'HEAT',        '수산화나트륨은 물에 녹을 때 열을 많이 내요.'),
    ('H2SO4', 'NACL',   40, '염화수소 기체',    'HCl GAS',     '진한 황산은 소금과 반응해 자극성 염화수소 기체를 내요.'),
    ('H2SO4', 'HCL',    40, '염화수소 기체',    'HCl GAS',     '진한 황산이 염산의 물을 빼앗아 염화수소 기체가 나와요.'),
    ('KMNO4', 'H2O2',   50, '산소 급발생',      'O2 BURST',    '과산화수소가 빠르게 분해되며 산소와 열이 나요.'),
    ('H2O2',  'NAOCL',  40, '산소 급발생',      'O2 BURST',    '두 산화제가 반응해 산소가 거품처럼 빠르게 나와요.'),
    ('H2SO4', 'NAHCO3', 25, 'CO2 거품 발생',    'CO2 FOAM',    '진한 황산과 탄산수소나트륨이 만나 이산화탄소와 열이 나요.'),
    ('HCL',   'NAHCO3', 15, 'CO2 거품 발생',    'CO2 FOAM',    '산과 탄산수소나트륨이 만나 이산화탄소 거품이 생겨요.'),
    ('ACOH',  'NAHCO3', 10, 'CO2 거품 발생',    'CO2 FOAM',    '아세트산과 탄산수소나트륨이 만나 이산화탄소 거품이 생겨요.'),
)

# 위험도 단계: (최소 %, 한글, 영어, LED 색)
LEVELS = ((70, '위험', 'DANGER', 'red'), (30, '주의', 'CAUTION', 'yellow'), (0, '안전', 'SAFE', 'green'))

# OLED 문구: (한글, 영어 대체)  — 한글은 한 줄 128px (한글 16px, 영문·숫자·공백 8px)
UI = {
    'IDLE1':     ('용매 토큰을',      'TAP SOLVENT'),
    'IDLE2':     ('대 주세요',        'TOKEN'),
    'SOLV':      ('용매: ',           'SOLV: '),
    'NOT_SOLV':  ('등록 안 된 토큰',  'NOT A SOLVENT'),
    'NEED_SOLV': ('용매 먼저 대요',   'SOLVENT FIRST'),
    'MAX':       ('최대 3개까지',     'MAX 3 ITEMS'),
    'DUP':       ('이미 선택함',      'ALREADY IN'),
    'NO_SUB':    ('물질을 고르세요',  'PICK 1-9'),
    'RESET':     ('초기화',           'RESET'),
    'READ_ERR':  ('읽기 오류',        'READ ERROR'),
    'NO_REACT':  ('특별한 반응 없음', 'NO REACTION'),
    'REG':       ('용매 등록 모드',   'REGISTER MODE'),
    'REG_TAP':   ('토큰을 대 주세요', 'TAP TOKEN'),
    'SAVED':     ('저장 완료',        'SAVED'),
    'FAIL':      ('저장 실패',        'WRITE FAIL'),
    'SAVE_KEY':  (' #저장',           ' #=SAVE'),
}

_RULE = {}
for _r in RULES:
    _RULE[tuple(sorted((_r[0], _r[1])))] = _r


def level_of(pct):
    for lv in LEVELS:
        if pct >= lv[0]:
            return lv
    return LEVELS[-1]


def evaluate(solvent, keys):
    """solvent: 'H2O' 등, keys: ['1', '4'] 등
    반환: (위험도 %, 단계, 반응 목록(위험 큰 순), 계산에 쓴 요인 목록)
    위험도 = 1 - (1-p1)(1-p2)...  (요인 중 하나라도 일어날 가능성을 합침)"""
    codes = [solvent] + [SUBSTANCES[k][0] for k in keys]
    factors = []                                   # (%, 이름, 설명)
    s = SOLVENTS[solvent]
    if s[2]:
        factors.append((s[2], s[0] + ' 자체', s[3]))
    for k in keys:
        sub = SUBSTANCES[k]
        if sub[3]:
            factors.append((sub[3], sub[1] + ' 자체', sub[4]))
    hazards = []
    for i in range(len(codes)):
        for j in range(i + 1, len(codes)):
            r = _RULE.get(tuple(sorted((codes[i], codes[j]))))
            if r:
                hazards.append(r)
                factors.append((r[2], r[3], r[5]))
    hazards.sort(key=lambda r: -r[2])
    keep = 1.0
    for f in factors:
        keep *= 1 - f[0] / 100
    pct = int((1 - keep) * 100 + 0.5)
    return pct, level_of(pct), hazards, factors


def report(solvent, keys):
    """evaluate 결과 + 노트북(Thonny) 화면에 찍을 한국어 설명 줄들"""
    pct, lv, hazards, factors = evaluate(solvent, keys)
    out = ['===== 케미체크 혼합 결과 =====',
           '용매: %s  |  섞은 물질: %s' % (SOLVENTS[solvent][0], ', '.join(SUBSTANCES[k][1] for k in keys))]
    if hazards:
        for r in hazards:
            out.append('[반응 %d%%] %s — %s' % (r[2], r[3], r[5]))
    else:
        out.append('[반응 없음] 규칙표에 위험한 조합이 없어요.')
    for f in factors:
        if f[1].endswith(' 자체'):
            out.append('[취급 %d%%] %s: %s' % (f[0], f[1], f[2]))
    if factors:
        terms = ''.join('(1-%.2f)' % (f[0] / 100) for f in factors)
        out.append('위험도 = 1 - %s = %d%%  → %s' % (terms, pct, lv[1]))
    else:
        out.append('위험도 = 0%% (위험 요인 없음)  → %s' % lv[1])
    return pct, lv, hazards, out
