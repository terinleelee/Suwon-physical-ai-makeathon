# =============================================================
#  케미체크 v2  test_parts.py — 부품 하나씩 점검
#  Thonny에서 실행(F5) → 아래 셸에 번호 입력. 배선 하나 끝낼 때마다 확인.
#  핀 번호는 main.py · 설계도 v2와 같음
# =============================================================
from machine import Pin, PWM, I2C
import time

PIN_SCK, PIN_MOSI, PIN_MISO, PIN_CS, PIN_RST = 18, 19, 16, 17, 20
PIN_SDA, PIN_SCL = 4, 5
ROW_PINS = (6, 7, 8, 9)
COL_PINS = (10, 11, 12, 13)
KEYMAP = ('123A', '456B', '789C', '*0#D')
PIN_SERVO = 15
GAUGE_0, GAUGE_100 = 180, 0
PIN_R, PIN_G, PIN_B = 21, 22, 26
PIN_BUZZER = 28
KEY_A = [0xFF] * 6


def test_rfid():
    from mfrc522 import MFRC522
    rdr = MFRC522(spi_id=0, sck=PIN_SCK, miso=PIN_MISO, mosi=PIN_MOSI, cs=PIN_CS, rst=PIN_RST,
                  baudrate=500000)
    print('리더기 버전:', hex(rdr._rreg(0x37)), '(0x84가 나오면 mfrc522.py가 옛날 버전)')
    print('토큰을 대 보세요 (Ctrl+C로 끝)')
    while True:
        rdr.reset()
        time.sleep_ms(50)
        for reg, val in ((0x2A, 0x8D), (0x2B, 0x3E), (0x2D, 30), (0x2C, 0), (0x15, 0x40),
                         (0x11, 0x3D), (0x26, 0x70), (0x18, 0x44), (0x28, 0x3F), (0x27, 0xF8)):
            rdr._wreg(reg, val)
        rdr._wreg(0x14, rdr._rreg(0x14) | 0x03)
        time.sleep_ms(10)
        stat, _ = rdr.request(rdr.REQIDL)
        if stat != rdr.OK:
            stat, _ = rdr.request(rdr.REQALL)
        if stat == rdr.OK:
            stat, uid = rdr.SelectTagSN()
            if stat == rdr.OK:
                u = ''.join('{:02X}'.format(b) for b in uid)
                if rdr.auth(rdr.AUTHENT1A, 4, KEY_A, uid) == rdr.OK:
                    r = rdr.read(4)
                    data = r[1] if isinstance(r, tuple) else r
                    txt = ''.join(chr(b) for b in list(data)[:16] if 33 <= b <= 126) if data else '(읽기 실패)'  # 뒤 2바이트는 검사값
                    print('UID', u, '| 4번 블록:', repr(txt), '(빈 토큰이면 main.py 등록 모드 D로 기록)')
                else:
                    print('UID', u, '| 인증 실패 (Key A가 기본값이 아님?)')
                rdr.stop_crypto1()
                time.sleep(1)
        time.sleep_ms(100)


def test_keypad():
    rows = [Pin(p, Pin.OUT, value=1) for p in ROW_PINS]
    cols = [Pin(p, Pin.IN, Pin.PULL_UP) for p in COL_PINS]
    print('키를 하나씩 눌러 보세요 (Ctrl+C로 끝)')
    print('누른 키와 찍힌 키가 다르면: 행이 바뀌면 ROW_PINS, 열이 바뀌면 COL_PINS 순서를 바꾸기')
    while True:
        for r, rp in enumerate(rows):
            rp.value(0)
            for c, cp in enumerate(cols):
                if cp.value() == 0:
                    print('키 %s  (R%d GP%d / C%d GP%d)' % (KEYMAP[r][c], r + 1, ROW_PINS[r], c + 1, COL_PINS[c]))
                    while cp.value() == 0:
                        time.sleep_ms(10)
            rp.value(1)
        time.sleep_ms(20)


def test_led():
    pins = [Pin(PIN_R, Pin.OUT), Pin(PIN_G, Pin.OUT), Pin(PIN_B, Pin.OUT)]
    for name, v in (('빨강', (1, 0, 0)), ('초록', (0, 1, 0)), ('파랑', (0, 0, 1)), ('노랑(빨강+초록)', (1, 1, 0))):
        for p, x in zip(pins, v):
            p.value(x)
        print(name, '켜짐?  (반대로 켜지면 main.py에서 LED_COMMON_ANODE = True)')
        time.sleep(1)
    for p in pins:
        p.value(0)


def test_buzzer():
    bz = Pin(PIN_BUZZER, Pin.OUT)
    for _ in range(2):
        bz.value(1)
        time.sleep_ms(200)
        bz.value(0)
        time.sleep_ms(200)
    print('삑 2번 들렸나요? (계속 울리면 main.py에서 BUZZER_ACTIVE_LOW = True)')


def test_servo():
    s = PWM(Pin(PIN_SERVO))
    s.freq(50)

    def go(pct):
        a = GAUGE_0 + (GAUGE_100 - GAUGE_0) * pct // 100
        s.duty_u16((500 + a * 2000 // 180) * 65535 // 20000)

    print('★ 바늘(수수깡)을 끼우기 전에 실행 → 0% 위치에서 바늘이 눈금 0을 가리키게 끼우세요')
    for pct in (0, 30, 70, 100, 0):
        print('위험도 %d%%' % pct)
        go(pct)
        time.sleep(1.2)
    print('100%가 반대쪽이면 main.py에서 GAUGE_0과 GAUGE_100을 맞바꾸기')


def test_oled():
    i2c = I2C(0, sda=Pin(PIN_SDA), scl=Pin(PIN_SCL), freq=400000)
    found = i2c.scan()
    print('I2C 주소:', [hex(a) for a in found], '(보통 0x3c)')
    if not found:
        print('→ 아무것도 없음: SDA/SCL 바뀜, 3.3V/GND 확인')
        return
    import ssd1306
    o = ssd1306.SSD1306_I2C(128, 32, i2c, addr=found[0])
    try:
        import hangul16
        hangul16.screen(o, '한글 테스트', '위험 93%', 93)
        print('OLED에 "한글 테스트 / 위험 93% + 막대"가 보이면 성공')
    except ImportError:
        o.fill(0)
        o.text('OLED OK', 0, 0)
        o.text('NO hangul16.py', 0, 12)
        print('hangul16.py가 Pico에 없어요 → 영어만 표시됨')
    o.show()


TESTS = {'1': ('RFID 리더기 + 토큰', test_rfid), '2': ('4x4 키패드', test_keypad),
         '3': ('3색 LED', test_led), '4': ('부저', test_buzzer),
         '5': ('서보 게이지 (0→100%)', test_servo), '6': ('OLED + 한글', test_oled)}

while True:
    print('\n===== 부품 점검 =====')
    for k, (name, _) in TESTS.items():
        print(k, name)
    k = input('번호 입력 > ').strip()
    if k in TESTS:
        try:
            TESTS[k][1]()
        except KeyboardInterrupt:
            print('점검 끝')
        except Exception as e:
            print('오류:', e)
