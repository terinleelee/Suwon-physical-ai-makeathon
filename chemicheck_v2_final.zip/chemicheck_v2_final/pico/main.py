# =============================================================
#  케미체크 v2  main.py — 섞기 전에 확인하는 시약 혼합 위험도 판별기
#  보드: Raspberry Pi Pico 2 WH  (MicroPython, Pico 2 W용 펌웨어)
#
#  Pico에 함께 저장할 파일
#    - chem_data.py  : 용매·물질·혼합 규칙 표 (이 파일만 고치면 규칙 변경)
#    - hangul16.py   : OLED 한글 글꼴 (없으면 영어로 표시)
#    - mfrc522.py    : 함께 준 [ChemiCheck 수정본] (원본은 최신 MicroPython에서 UID를 못 읽음)
#    - ssd1306.py    : micropython-lib 의 ssd1306 드라이버
#  "Raspberry Pi Pico에 저장"으로 올리면 USB 충전기만 꽂아도 자동 실행됩니다.
#
#  사용법: 파란 토큰(용매) 대기 → 키패드 1~9로 물질(최대 3개) → # 섞기
#          * 마지막 삭제 · A/B 반응 넘기기 · C 처음으로 · D 용매 토큰 등록
# =============================================================
from machine import Pin, PWM, I2C
import time
import chem_data as cd

# ---------------- 설정 (현장에서 바꾸는 값) ----------------
USE_UID_TABLE = False       # 토큰 쓰기가 끝내 안 되면 True + 아래 표 채우기
UID_TABLE = {
    # 'A1B2C3D4': 'ETOH',      # Thonny 화면에 찍히는 UID : 용매 코드(H2O/ETOH/ACET/ACOH)
}
LED_COMMON_ANODE = False    # 3색 LED가 반대로 켜지면 True
BUZZER_ACTIVE_LOW = False   # 부저가 계속 울리면 True
USE_GAUGE = True            # 서보 게이지를 안 달면 False
GAUGE_0 = 180               # 위험도 0% 일 때 서보 각도
GAUGE_100 = 0               # 위험도 100% 일 때 서보 각도 (바늘이 반대로 가면 두 값을 맞바꾸기)
WRITE_SECONDS = 10          # 등록 모드에서 토큰을 기다리는 시간
MSG_MS = 1300               # 안내 문구를 보여 주는 시간
RFID_RESET_WAIT = 50        # 리더기 리셋 후 대기(ms). 키패드가 둔하면 20으로 줄여 보기
RF_EVERY = 150              # 토큰을 확인하는 간격(ms). 그 사이에는 키패드만 확인

# ---------------- 핀 배치 (설계도와 같음) ----------------
PIN_SCK, PIN_MOSI, PIN_MISO, PIN_CS, PIN_RST = 18, 19, 16, 17, 20   # RC522 (SPI0)
PIN_SDA, PIN_SCL = 4, 5                                             # OLED (I2C0)
ROW_PINS = (6, 7, 8, 9)                                             # 키패드 R1~R4
COL_PINS = (10, 11, 12, 13)                                         # 키패드 C1~C4
KEYMAP = ('123A', '456B', '789C', '*0#D')
PIN_SERVO = 15                                                      # 게이지 서보
PIN_R, PIN_G, PIN_B = 21, 22, 26                                    # 3색 LED
PIN_BUZZER = 28                                                     # 능동 부저

DATA_BLOCK = 4                       # 0, 3, 7, 11 ... 63 번 블록은 절대 쓰지 않음
KEY_A = [0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF]

# ---------------- 출력 장치 ----------------
led_pins = (Pin(PIN_R, Pin.OUT), Pin(PIN_G, Pin.OUT), Pin(PIN_B, Pin.OUT))
buzzer = Pin(PIN_BUZZER, Pin.OUT)
LED_COLORS = {'off': (0, 0, 0), 'red': (1, 0, 0), 'green': (0, 1, 0),
              'blue': (0, 0, 1), 'yellow': (1, 1, 0)}


def led(color):
    for pin, v in zip(led_pins, LED_COLORS[color]):
        pin.value(1 - v if LED_COMMON_ANODE else v)


def buzz(on):
    buzzer.value((0 if on else 1) if BUZZER_ACTIVE_LOW else (1 if on else 0))


def beep(ms):
    buzz(True)
    time.sleep_ms(ms)
    buzz(False)


def alarm(level_color):
    if level_color == 'red':
        for _ in range(3):
            beep(200)
            time.sleep_ms(150)
    elif level_color == 'yellow':
        beep(500)
    else:
        beep(80)


servo = None
gauge_angle = GAUGE_0
if USE_GAUGE:
    servo = PWM(Pin(PIN_SERVO))
    servo.freq(50)


def servo_angle(a):
    if servo:
        us = 500 + int(a) * 2000 // 180              # SG-90: 0.5ms=0°, 2.5ms=180°
        servo.duty_u16(us * 65535 // 20000)


def gauge(pct, animate=True):
    """바늘을 위험도 pct(0~100) 위치로"""
    global gauge_angle
    target = GAUGE_0 + (GAUGE_100 - GAUGE_0) * pct // 100
    if animate and servo:
        step = 3 if target > gauge_angle else -3
        for a in range(gauge_angle, target, step):
            servo_angle(a)
            time.sleep_ms(12)
    servo_angle(target)
    gauge_angle = target


# ---------------- OLED (한글 → 없으면 영어 → 없으면 Thonny 화면) ----------------
oled = None
hg = None
try:
    import ssd1306
    _i2c = I2C(0, sda=Pin(PIN_SDA), scl=Pin(PIN_SCL), freq=400000)
    _found = _i2c.scan()
    if 0x3C in _found or 0x3D in _found:
        oled = ssd1306.SSD1306_I2C(128, 32, _i2c, addr=0x3C if 0x3C in _found else 0x3D)
    else:
        print('OLED를 못 찾음 (I2C 주소:', _found, ') → Thonny 화면으로 대신 표시')
except Exception as e:
    print('OLED 사용 안 함:', e)
try:
    import hangul16 as hg
except Exception as e:
    print('hangul16.py 없음 → OLED는 영어로 표시:', e)


def draw(l1, l2='', e1='', e2='', pct=None, page=None):
    """l1·l2 = 한글 화면, e1·e2 = 영어 대체 문구"""
    print('[OLED] %s / %s%s%s' % (l1, l2, '' if pct is None else '  [막대 %d%%]' % pct,
                                  ' [%s]' % page if page else ''))
    if not oled:
        return
    if hg:
        hg.screen(oled, l1, l2, pct, page)
    else:
        oled.fill(0)
        oled.text(e1[:16], 0, 0)
        oled.text(e2[:16], 0, 12)
        if pct is not None:
            oled.rect(0, 24, 128, 8, 1)
            oled.fill_rect(2, 26, 124 * pct // 100, 4, 1)
    oled.show()


# ---------------- 키패드 ----------------
rows = [Pin(p, Pin.OUT, value=1) for p in ROW_PINS]
cols = [Pin(p, Pin.IN, Pin.PULL_UP) for p in COL_PINS]


def scan():
    for r, rp in enumerate(rows):
        rp.value(0)
        for c, cp in enumerate(cols):
            if cp.value() == 0:
                rp.value(1)
                return KEYMAP[r][c]
        rp.value(1)
    return None


key_latch = None      # 리더기를 기다리는 동안 눌렸던 키를 기억


def wait_poll(ms):
    """ms 동안 기다리면서 키패드도 확인 → 리더기 확인 중에 짧게 눌러도 놓치지 않음"""
    global key_latch
    t0 = time.ticks_ms()
    prev = None
    while time.ticks_diff(time.ticks_ms(), t0) < ms:
        if key_latch is None:
            k = scan()
            if k is not None and k == prev:     # 5ms 간격으로 두 번 같으면 진짜 눌림
                key_latch = k
            prev = k
        time.sleep_ms(5)


def get_key():
    """눌린 키 하나를 돌려줌 (손을 뗄 때까지 기다림), 없으면 None"""
    global key_latch
    latched, key_latch = key_latch, None        # 리더기 확인 중에 눌렸던 키
    k = scan()
    if k is not None:
        time.sleep_ms(20)
        if scan() == k:                         # 아직 누르고 있음 → 뗄 때까지 기다렸다가 한 번만
            beep(15)                            # 딸깍
            while scan() is not None:
                time.sleep_ms(10)
            return k
    if latched is not None:                     # 이미 손을 뗐어도 놓치지 않음
        beep(15)
        return latched
    return None


# ---------------- RFID ----------------
from mfrc522 import MFRC522
rdr = MFRC522(spi_id=0, sck=PIN_SCK, miso=PIN_MISO, mosi=PIN_MOSI, cs=PIN_CS, rst=PIN_RST,
              baudrate=500000)


def rfid_setup():
    """리더기 초기화 — 실제 키트에서 인식에 성공한 설정 (rfid_test5)"""
    rdr.reset()
    wait_poll(RFID_RESET_WAIT)              # 리셋 후 칩이 깨어날 시간 (그동안 키패드 확인)
    rdr._wreg(0x2A, 0x8D)
    rdr._wreg(0x2B, 0x3E)
    rdr._wreg(0x2D, 30)
    rdr._wreg(0x2C, 0)
    rdr._wreg(0x15, 0x40)
    rdr._wreg(0x11, 0x3D)
    rdr._wreg(0x26, 0x70)                   # 수신 감도 최대
    rdr._wreg(0x18, 0x44)                   # 수신 기준 낮춤
    rdr._wreg(0x28, 0x3F)                   # 송신 세기 최대
    rdr._wreg(0x27, 0xF8)
    rdr._wreg(0x14, rdr._rreg(0x14) | 0x03)  # 안테나 켜기
    wait_poll(10)


def detect():
    """토큰이 있으면 UID(리스트), 없으면 None"""
    rfid_setup()                            # 매번 초기화 → 올려 둔 토큰도 한 번만 처리됨
    stat, _ = rdr.request(rdr.REQIDL)
    if stat != rdr.OK:
        stat, _ = rdr.request(rdr.REQALL)
    if stat != rdr.OK:
        return None
    if hasattr(rdr, 'SelectTagSN'):
        stat, uid = rdr.SelectTagSN()
    else:
        stat, uid = rdr.anticoll()
        if stat == rdr.OK:
            rdr.select_tag(uid)
    return uid if stat == rdr.OK else None


def uid_str(uid):
    return ''.join('{:02X}'.format(b) for b in uid)


def _read_raw():
    r = rdr.read(DATA_BLOCK)
    if isinstance(r, tuple):                    # 라이브러리 버전에 따라 (stat, data)
        return r[1] if r[0] == rdr.OK else None
    return r


def read_solvent(uid):
    """반환: (용매 코드 또는 None, 오류 여부)"""
    u = uid_str(uid)
    if USE_UID_TABLE:
        return UID_TABLE.get(u), False
    if rdr.auth(rdr.AUTHENT1A, DATA_BLOCK, KEY_A, uid) != rdr.OK:
        rdr.stop_crypto1()
        return None, True
    data = _read_raw()
    rdr.stop_crypto1()
    if data is None:
        return None, True
    # 읽은 값 끝에 검사값(CRC) 2바이트가 붙어 오므로 앞 16바이트만 사용
    # (안 자르면 아세톤·아세트산 토큰이 'SV|ACETC'처럼 읽혀 "등록 안 된 토큰"이 됨)
    text = ''.join(chr(b) for b in list(data)[:16] if 33 <= b <= 126)
    print('토큰 UID:', u, ' 4번 블록:', repr(text))
    if text.startswith('SV|') and text[3:] in cd.SOLVENTS:
        return text[3:], False
    return None, False


def write_solvent(uid, code):
    buf = [ord(c) for c in ('SV|' + code + ' ' * 16)[:16]]
    if rdr.auth(rdr.AUTHENT1A, DATA_BLOCK, KEY_A, uid) != rdr.OK:
        rdr.stop_crypto1()
        return False
    ok = False
    if rdr.write(DATA_BLOCK, buf) == rdr.OK:
        back = _read_raw()
        ok = back is not None and list(back)[:16] == buf
    rdr.stop_crypto1()
    return ok


def wait_tag(seconds):
    t0 = time.ticks_ms()
    while time.ticks_diff(time.ticks_ms(), t0) < seconds * 1000:
        uid = detect()
        if uid:
            print('[등록] 토큰 발견:', uid_str(uid), '→ 기록 중... 떼지 마세요')
            return uid
        time.sleep_ms(50)
    print('[등록] %d초 동안 토큰이 안 보였어요. 다시 # 누르고 토큰을 대 주세요' % seconds)
    return None


# ---------------- 상태 ----------------
mode = 'mix'          # 'mix' = 혼합 판별, 'register' = 용매 토큰 등록
solvent = None        # 'H2O' 등
picks = []            # 고른 키 ['1', '4']
result = None         # (위험도 %, 단계, 반응 목록)
page = 0
reg_sel = 0
last_uid = None
misses = 0


def picks_line():
    sf = cd.SOLVENTS[solvent][1]
    s = sf + ''.join('+' + cd.SUBSTANCES[k][2] for k in picks)
    return s if len(s) <= 16 else sf + ' #' + ','.join(picks)


def redraw():
    if mode == 'register':
        k = cd.SOLVENT_KEYS[reg_sel]
        s = cd.SOLVENTS[k]
        draw(cd.UI['REG'][0], '%d:%s%s' % (reg_sel + 1, s[0], cd.UI['SAVE_KEY'][0]),
             cd.UI['REG'][1], '%d:%s%s' % (reg_sel + 1, s[1], cd.UI['SAVE_KEY'][1]))
    elif result:
        pct, lv, hz = result
        pg = '%d/%d' % (page + 1, len(hz)) if len(hz) > 1 else None
        if hz:
            l1, e1 = hz[page][3], hz[page][4]
        else:
            l1, e1 = cd.UI['NO_REACT']
        draw(l1, '%s %d%%' % (lv[1], pct), e1, '%s %d%%' % (lv[2], pct), pct, pg)
    elif solvent is None:
        draw(cd.UI['IDLE1'][0], cd.UI['IDLE2'][0], cd.UI['IDLE1'][1], cd.UI['IDLE2'][1])
    elif not picks:
        s = cd.SOLVENTS[solvent]
        draw(cd.UI['SOLV'][0] + s[0], '1-9 ADD  #=MIX', cd.UI['SOLV'][1] + s[1], '1-9 ADD  #=MIX')
    else:
        sub = cd.SUBSTANCES[picks[-1]]
        draw(sub[1], picks_line(), '+' + sub[2], picks_line())


def led_state():
    if mode == 'register':
        led('blue')
    elif result:
        led(result[1][3])
    else:
        led('off')


def message(key, l2='', e2='', color=None, beep_ms=0):
    ko, en = cd.UI[key]
    draw(ko, l2, en, e2)
    if color:
        led(color)
    if beep_ms:
        beep(beep_ms)
    time.sleep_ms(MSG_MS)
    led_state()
    redraw()


def clear_result():
    global result, page
    if result:
        result = None
        page = 0
        led('off')
        gauge(0, animate=False)


def mix():
    global result, page
    pct, lv, hz, lines = cd.report(solvent, picks)
    for ln in lines:
        print(ln)
    result = (pct, lv, hz)
    page = 0
    redraw()
    led(lv[3])
    gauge(pct)
    alarm(lv[3])


# ---------------- 키·토큰 처리 ----------------
def on_key(k):
    global mode, solvent, picks, page, reg_sel
    print('키:', k)
    if mode == 'register':
        if k in '1234':
            reg_sel = int(k) - 1
            redraw()
        elif k == '#':
            register_token()
        elif k in 'CD':
            mode = 'mix'
            led_state()
            redraw()
        return

    if k in cd.SUBSTANCES:
        if solvent is None:
            message('NEED_SOLV', beep_ms=300)
        elif k in picks:
            message('DUP')
        elif len(picks) >= cd.MAX_PICK:
            message('MAX', beep_ms=300)
        else:
            picks.append(k)
            clear_result()
            redraw()
    elif k == '*':
        if picks:
            picks.pop()
            clear_result()
            redraw()
    elif k == '#':
        if solvent is None:
            message('NEED_SOLV', beep_ms=300)
        elif not picks:
            message('NO_SUB', beep_ms=300)
        else:
            mix()
    elif k in 'AB':
        if result and len(result[2]) > 1:
            page = (page + (1 if k == 'B' else -1)) % len(result[2])
            redraw()
    elif k == 'C':
        clear_result()
        solvent = None
        picks = []
        gauge(0, animate=False)
        message('RESET')
    elif k == 'D':
        clear_result()
        mode = 'register'
        led_state()
        redraw()


def on_token(uid):
    global solvent
    u = uid_str(uid)
    code, err = read_solvent(uid)
    if err:
        message('READ_ERR', u, u, 'red', 600)
    elif mode == 'register':                    # 등록 모드에서 그냥 대면 내용 확인
        if code:
            s = cd.SOLVENTS[code]
            draw(cd.UI['SOLV'][0] + s[0], u, cd.UI['SOLV'][1] + s[1], u)
            time.sleep_ms(MSG_MS)
            redraw()
        else:
            message('NOT_SOLV', u, u)
    elif code is None:
        message('NOT_SOLV', u, u, 'red', 600)
    else:
        solvent = code
        clear_result()
        beep(80)
        print('[용매] %s (%s)' % (cd.SOLVENTS[code][0], cd.SOLVENTS[code][3]))
        redraw()


def register_token():
    global last_uid
    code = cd.SOLVENT_KEYS[reg_sel]
    print('[등록] %s(%s) 기록 준비 → %d초 안에 빈 토큰을 대 주세요'
          % (cd.SOLVENTS[code][0], code, WRITE_SECONDS))
    draw(cd.UI['REG_TAP'][0], 'SV|' + code, cd.UI['REG_TAP'][1], 'SV|' + code)
    uid = wait_tag(WRITE_SECONDS)
    if uid is None:
        redraw()
        return
    last_uid = uid_str(uid)
    if write_solvent(uid, code):
        print('[기록 성공]', last_uid, '← SV|' + code)
        message('SAVED', 'SV|' + code, 'SV|' + code, 'green', 100)
    else:
        print('[기록 실패] 토큰을 리더기에 더 오래 대고 다시 시도')
        message('FAIL', 'TRY AGAIN', 'TRY AGAIN', 'red', 800)


# ---------------- 시작 ----------------
def main():
    global last_uid, misses
    draw('CHEMICHECK v2', 'SAFE LAB', 'CHEMICHECK v2', 'SAFE LAB')
    gauge(0, animate=False)
    led('off')
    beep(100)
    time.sleep_ms(600)
    redraw()
    print('준비 완료 — 키를 누르면 셸에 "키: D"처럼 찍혀요')
    t_rf = time.ticks_ms()
    while True:
        try:
            k = get_key()                           # 키패드는 10ms마다 확인 (짧게 눌러도 잡힘)
            if k:
                on_key(k)
            if time.ticks_diff(time.ticks_ms(), t_rf) >= RF_EVERY:
                uid = detect()                      # 리더기는 RF_EVERY ms마다 확인
                t_rf = time.ticks_ms()
                if uid:
                    misses = 0
                    u = uid_str(uid)
                    if u != last_uid:               # 리더기 위에 둔 토큰은 한 번만 처리
                        last_uid = u
                        on_token(uid)
                else:
                    misses += 1
                    if misses >= 3:
                        last_uid = None
        except Exception as e:                      # 시연 중 멈추지 않게
            print('오류:', e)
            draw('ERROR', str(e)[:16], 'ERROR', str(e)[:16])
            time.sleep(1)
            led_state()
            redraw()
        time.sleep_ms(10)


main()
